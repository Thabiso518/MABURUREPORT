document.getElementById("download").addEventListener("click", function() {
  alert("PDF export feature coming soon!");
});
